# Yatra Mitra AI - India Travel Chatbot (NLP + Kaggle Dataset)

## Folder structure
```text
yatra-mitra-ai/
├── index.html
├── Top Indian Places to Visit.csv
├── README.md
├── css/
│   └── style.css
└── js/
    ├── config.js
    ├── services.js
    ├── llm.js
    └── ui.js
```

## How to run
1. Extract this zip archive and open the `yatra-mitra-ai` folder in a local web server (for example VS Code **Live Server**, `npx serve`, or `python -m http.server`) so `Top Indian Places to Visit.csv` loads over HTTP.
2. Check `js/config.js` for your `PROVIDER`, `API_KEY`, and `MODELS`.
3. Ask about any tourist place in India — the chatbot checks **NLP first**, falls back to **`Top Indian Places to Visit.csv`** when needed, and presents the final response.
