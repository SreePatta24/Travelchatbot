/* ===== llm.js - NLP brain + Kaggle dataset fallback synthesis ===== */

const modelName = () => CONFIG.MODELS[CONFIG.PROVIDER];

async function callLLM({ system, messages, max = 1500, json = false }) {
  const key = CONFIG.API_KEY;
  if (!key || key.startsWith("PASTE")) throw new Error("NO_KEY");
  const P = CONFIG.PROVIDER, model = modelName();
  let url, headers = { "content-type": "application/json" }, body;

  if (P === "anthropic") {
    url = "https://api.anthropic.com/v1/messages";
    headers["x-api-key"] = key;
    headers["anthropic-version"] = "2023-06-01";
    headers["anthropic-dangerous-direct-browser-access"] = "true";
    body = { model, max_tokens: max, system, messages };
  } else if (P === "openai") {
    url = "https://api.openai.com/v1/chat/completions";
    headers.Authorization = "Bearer " + key;
    body = { model, max_tokens: max, messages: [{ role: "system", content: system }, ...messages] };
    if (json) body.response_format = { type: "json_object" };
  } else {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
    body = {
      systemInstruction: { parts: [{ text: system }] },
      contents: messages.map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })),
      generationConfig: { maxOutputTokens: max, ...(json ? { responseMimeType: "application/json" } : {}) }
    };
  }

  const res = await fetch(url, { method: "POST", headers, body: JSON.stringify(body) });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error?.message || j.error || "API error " + res.status);
  if (P === "anthropic") return (j.content || []).map(b => b.text || "").join("");
  if (P === "openai") return j.choices?.[0]?.message?.content || "";
  return (j.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("");
}

function parseJSON(t) {
  let clean = String(t || "").replace(/```json|```/gi, "").trim();
  const a = clean.indexOf("{"), b = clean.lastIndexOf("}");
  if (a !== -1 && b !== -1 && b > a) clean = clean.slice(a, b + 1);
  return JSON.parse(clean);
}
const askJSON = async (prompt, max = 1500) =>
  parseJSON(await callLLM({ system: SYS + " " + ONLY_JSON, messages: [{ role: "user", content: prompt }], max, json: true }));

const SYS = "You are Yatra Mitra, an expert and friendly travel assistant for India. Use Indian Rupees. Prices, timings and travel times are approximate estimates; never invent hotel names, phone numbers or fake facts.";
const ONLY_JSON = "Respond with ONLY one valid JSON object. No markdown fences and no commentary.";

/* ---------- Step 1: Primary NLP Brain ---------- */
const NLU_SYSTEM = `${SYS}
You are also the language-understanding engine of a travel chatbot. Understand the user's latest message using the conversation so far (resolve words like "there", "it", "that place").
Reply in the SAME language and script the user writes in (English, Hindi, Telugu, Tamil, Hinglish, etc.).
Return ONLY this JSON object:
{"intent":"chat|trip_plan|budget|weather|packing|map|photos|reviews|compare|month_ideas|interest_ideas|surprise|greeting|off_topic",
"language":"detected language","place":"main Indian place, canonical English name, or null","places":["two places, only for compare"],
"origin":"starting city or null","days":number or null,"travellers":number or null,"hotel":"basic|medium|luxury|null",
"month":"month name or null","interest":"beach|hills|heritage|spiritual|wildlife|adventure|food|null","confidence":0-100,"reply":"markdown answer"}
Intent rules:
- trip_plan: wants a day-wise trip, itinerary or full trip suggestion. budget: wants a trip cost calculator. weather: current or forecast weather. packing: what to pack. map: wants a map. photos/reviews: wants pictures or reviews. compare: compares two places. month_ideas: where to go in a given month. interest_ideas: destinations by interest. surprise: random suggestion.
- chat: any other India travel question. Put a helpful answer in "reply": under 200 words, short bullet points, include approximate costs (Rs), timings and local tips where useful, and end with one follow-up suggestion.
- greeting / off_topic: give a short friendly reply; for off_topic politely steer back to India travel.
- For all other intents "reply" can be an empty string.`;

async function understand(text, history) {
  const raw = await callLLM({ system: NLU_SYSTEM, messages: [...history, { role: "user", content: text }], max: 1200, json: true });
  let u;
  try { u = parseJSON(raw); } catch (e) { u = { intent: "chat", reply: raw, confidence: 50 }; }
  u._raw = raw; u.intent = u.intent || "chat";
  return u;
}

/* ---------- Step 2 Fallback: Answer using Kaggle Dataset + NLP ---------- */
async function answerWithDatasetFallback(text, u, matches) {
  const summary = matches.map(m => `${m.name} (${[m.city, m.state, m.type].filter(Boolean).join(", ")}; rating ${m.rating || "N/A"}; fee ${m.fee || "N/A"}; hrs ${m.hrs || "N/A"})`).join(" | ");
  const prompt = `User question: "${text}"
Detected language: ${u.language || "English"}.
Kaggle dataset matching rows: ${summary}
Write a concise, helpful response (under 200 words, matching the user's language) incorporating these dataset details naturally, plus practical timings/tips and one follow-up suggestion.`;
  return callLLM({ system: SYS, messages: [{ role: "user", content: prompt }], max: 800, json: false });
}

/* ---------- Feature generators ---------- */
const RATES = `"rates":{"room":{"basic":0,"medium":0,"luxury":0},"food":{"basic":0,"medium":0,"luxury":0},"local":{"basic":0,"medium":0,"luxury":0},"activities":0}`;
const RATE_RULES = "All money values are INR numbers. room = price per room per night; food = per person per day; local = taxi/auto per day for the whole group; activities = entry fees and activities per person per day.";

const genPlan = (place, days, n, origin) => askJSON(
  `Plan a ${days}-day trip to ${place}, India for ${n} traveller(s)${origin ? ", starting from " + origin : ""}.
JSON shape: {"place":"canonical name","state":"","best_time":"","summary":"one line",
"transport":[{"mode":"Train","one_way_hours":0,"cost_return_per_person":0,"practical":true,"note":""},{"mode":"Flight","one_way_hours":0,"cost_return_per_person":0,"practical":true,"note":""},{"mode":"Car","one_way_hours":0,"cost_return_per_vehicle":0,"practical":true,"note":""}],
${RATES},
"itinerary":[{"day":1,"title":"","spots":[{"name":"","timing":"","cost":"","special":""}]}],"food":[""],"tips":[""]}
Rules: ${RATE_RULES} Transport costs are round trip (train 3AC, economy flight, a cab for up to 4 people). Set practical=false with a note if a mode makes no sense. Give exactly ${days} itinerary days with 2 or 3 spots each. Use real, well-known attractions whose names exist on Wikipedia. timing like "9 AM to 5 PM, closed Mondays"; cost like "Rs 50" or "Free"; special = what makes it unique.`, 4000);

const _rates = {};
const genRates = async place => _rates[place] ||= (await askJSON(`Typical 2025-26 travel cost rates for tourists in ${place}, India. JSON shape: {${RATES}} Rules: ${RATE_RULES}`, 600));

const _spots = {};
const genSpots = async place => _spots[place] ||= (await askJSON(
  `List the top 8 tourist attractions of ${place}, India. JSON shape: {"place":"canonical name","state":"","lat":0,"lon":0,"spots":[{"name":"Wikipedia-style name","lat":0,"lon":0}]}`, 900));

const genPack = (place, month, type) => askJSON(
  `Create a packing checklist for a trip to ${place}, India in ${month}${type ? " (" + type + ")" : ""}. Consider weather, terrain, culture and permits. JSON shape: {"groups":[{"title":"","items":[""]}]} with 5 to 7 groups and 3 to 6 short items each.`, 1200);

const genIdeas = a => askJSON(
  `${a.surprise ? "Suggest ONE surprising, less-obvious destination in India." : a.month ? `List the 8 best destinations in India to visit in ${a.month}.` : `List the 8 best ${a.interest} destinations in India.`} JSON shape: {"title":"short heading","places":[{"name":"","state":"","best_time":"","why":"one short sentence"}]}`, 1200);

const genCompare = (a, b) => askJSON(
  `Compare ${a} and ${b} (India) for tourists. JSON shape: {"a":{"name":"","state":"","best_time":"","ideal_days":0,"cost_per_person_per_day_inr":0,"top_sights":[""],"food":[""],"vibe":""},"b":{same fields},"verdict":"2 sentences on who should pick which"}`, 1200);

const genReviews = place => askJSON(
  `Summarise what travellers generally say about ${place}, India, from your general knowledge (this is not live review data). JSON shape: {"rating":4.5,"summary":"one sentence","likes":["",""],"dislikes":["",""],"tips":["",""]}`, 700);
