/* ===== config.js - provider, model and Kaggle CSV settings ===== */
const CONFIG = {
  PROVIDER: "gemini",                 // "anthropic" (Claude) | "openai" | "gemini"
  API_KEY: "AQ.Ab8RN6IEQltt9NBQGVD8prn_Zg6WDgABlqCbNaClifm-OV8xAg",
  MODELS: {
    anthropic: "claude-sonnet-5-5",
    openai: "gpt-4o-mini",
    gemini: "gemini-3.8-flash"
  },
  MAX_HISTORY: 8,
  DATASET_PATHS: [
    "Top Indian Places to Visit.csv",
    "data/Top Indian Places to Visit.csv"
  ],
  NLP_CONFIDENCE_THRESHOLD: 65        // if NLP confidence is below this or place is missing, check Kaggle dataset
};
