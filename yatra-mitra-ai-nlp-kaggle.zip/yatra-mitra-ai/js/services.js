/* ===== services.js - helpers, Kaggle CSV loader/search + free public services ===== */

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const cap = s => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const N = x => { const v = Number(x); return Number.isFinite(v) ? v : 0; };
const inr = n => "Rs " + Math.round(N(n)).toLocaleString("en-IN");
const sleep = ms => new Promise(r => setTimeout(r, ms));
const clamp = (v, a, b) => Math.min(Math.max(N(v), a), b);
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const HOTEL = { basic: "Basic", medium: "Medium", luxury: "Luxury" };
const TYPES = ["basic", "medium", "luxury"];

/* Tiny markdown renderer for LLM replies */
function md(t) {
  let out = "", ul = false;
  for (let l of esc(t || "").split("\n")) {
    l = l.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
    const b = l.match(/^\s*(?:[-*•]|\d+\.)\s+(.*)/);
    if (b) { if (!ul) { out += "<ul>"; ul = true; } out += "<li>" + b[1] + "</li>"; continue; }
    if (ul) { out += "</ul>"; ul = false; }
    if (/^#{1,4}\s/.test(l)) out += "<h4>" + l.replace(/^#+\s*/, "") + "</h4>";
    else if (l.trim()) out += "<p>" + l + "</p>";
  }
  return out + (ul ? "</ul>" : "");
}

/* ---------- Kaggle Dataset ("Top Indian Places to Visit.csv") ---------- */
let _DS = null, _DS_STATUS = "unloaded";

function parseCSV(text) {
  const rows = [];
  let row = [], val = "", inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i], next = text[i + 1];
    if (inQuotes) {
      if (ch === '"' && next === '"') { val += '"'; i++; }
      else if (ch === '"') inQuotes = false;
      else val += ch;
    } else {
      if (ch === '"') inQuotes = true;
      else if (ch === ",") { row.push(val.trim()); val = ""; }
      else if (ch === "\n" || ch === "\r") {
        if (ch === "\r" && next === "\n") i++;
        row.push(val.trim()); val = "";
        if (row.some(cell => cell !== "")) rows.push(row);
        row = [];
      } else val += ch;
    }
  }
  if (val !== "" || row.length) { row.push(val.trim()); if (row.some(cell => cell !== "")) rows.push(row); }
  if (!rows.length) return [];
  const headers = rows[0].map(h => h.replace(/^\uFEFF/, "").trim());
  return rows.slice(1).map(r => Object.fromEntries(headers.map((h, idx) => [h, r[idx] ?? ""])));
}

async function loadKaggleDataset() {
  if (_DS) return _DS;
  const paths = CONFIG.DATASET_PATHS || ["Top Indian Places to Visit.csv"];
  for (const p of paths) {
    try {
      const res = await fetch(encodeURI(p));
      if (!res.ok) continue;
      const txt = await res.text();
      const parsed = parseCSV(txt);
      if (parsed.length) {
        _DS = parsed;
        _DS_STATUS = `loaded (${parsed.length} rows from ${p})`;
        return _DS;
      }
    } catch (e) { }
  }
  _DS_STATUS = "not found (serve over HTTP/HTTPS with 'Top Indian Places to Visit.csv' in project folder)";
  return [];
}

function getDatasetStatus() { return _DS_STATUS; }

function pickField(obj, keys) {
  for (const k of keys) {
    if (obj[k] !== undefined && String(obj[k]).trim() !== "") return String(obj[k]).trim();
  }
  return "";
}

async function queryKaggleDataset(queryText, hintPlace = null) {
  const rows = await loadKaggleDataset();
  if (!rows.length) return [];
  const q = String(queryText || "").toLowerCase();
  const hp = String(hintPlace || "").toLowerCase().trim();
  const terms = q.replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(w => w.length > 2 && !["the", "and", "for", "with", "from", "trip", "visit", "place", "places", "india", "tell", "about", "where", "best", "top"].includes(w));

  const scored = rows.map(r => {
    const name = pickField(r, ["Name", "name", "Place", "Place Name", "Tourist Place"]).toLowerCase();
    const city = pickField(r, ["City", "city"]).toLowerCase();
    const state = pickField(r, ["State", "state"]).toLowerCase();
    const zone = pickField(r, ["Zone", "zone"]).toLowerCase();
    const type = pickField(r, ["Type", "type", "Category"]).toLowerCase();
    const blob = `${name} ${city} ${state} ${zone} ${type}`;
    let score = 0;

    if (hp) {
      if (city === hp || state === hp) score += 12;
      if (name.includes(hp) || city.includes(hp) || state.includes(hp)) score += 8;
    }
    for (const t of terms) {
      if (city === t || state === t) score += 7;
      else if (name.includes(t)) score += 5;
      else if (blob.includes(t)) score += 2;
    }
    return { score, row: r };
  }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);

  return scored.slice(0, 6).map(x => ({
    name: pickField(x.row, ["Name", "name", "Place", "Place Name"]) || "Attraction",
    city: pickField(x.row, ["City", "city"]),
    state: pickField(x.row, ["State", "state"]),
    zone: pickField(x.row, ["Zone", "zone"]),
    type: pickField(x.row, ["Type", "type", "Category"]),
    rating: pickField(x.row, ["Google review rating", "Rating", "rating"]),
    hrs: pickField(x.row, ["time needed to visit in hrs", "Time Needed to Visit (hrs)", "Time"]),
    fee: pickField(x.row, ["Entrance Fee in INR", "Entrance Fee", "Fee"]),
    bestTime: pickField(x.row, ["Best Time to visit", "Best Time"])
  }));
}

function formatDatasetMatches(matches) {
  if (!matches.length) return "";
  return `<div class="ds-box"><b>📊 Kaggle Dataset Matches (Top Indian Places to Visit):</b><ul>` +
    matches.map(m => {
      const loc = [m.city, m.state, m.zone].filter(Boolean).join(", ");
      const meta = [
        m.type && `Type: ${m.type}`,
        m.rating && `Rating: ${m.rating}`,
        m.hrs && `~${m.hrs} hrs`,
        m.fee && `Fee: Rs ${m.fee}`,
        m.bestTime && `Best: ${m.bestTime}`
      ].filter(Boolean).join(" · ");
      return `<li><b>${esc(m.name)}</b>${loc ? ` (${esc(loc)})` : ""}${meta ? `<br><small>${esc(meta)}</small>` : ""}</li>`;
    }).join("") + `</ul></div>`;
}

/* ---------- Photos from Wikipedia ---------- */
const IMG = {};
async function wikiImg(q) {
  if (q in IMG) return IMG[q];
  let r = null;
  try {
    const res = await fetch("https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrlimit=1&prop=pageimages&piprop=thumbnail&pithumbsize=560&gsrsearch=" + encodeURIComponent(q));
    const j = await res.json();
    const pg = j.query && Object.values(j.query.pages)[0];
    r = pg && pg.thumbnail ? { src: pg.thumbnail.source, t: pg.title } : null;
  } catch (e) { }
  return (IMG[q] = r);
}
const ph = (...qs) => `<div class="ph" data-img="${esc(qs.join("||"))}"></div>`;
function hydrate(root) {
  root.querySelectorAll(".ph[data-img]").forEach(async el => {
    const q = el.dataset.img; el.removeAttribute("data-img");
    let r = null;
    for (const k of q.split("||")) { r = await wikiImg(k); if (r) break; }
    if (!r) return el.classList.add("none");
    const i = new Image(); i.alt = r.t || "Destination photo"; i.referrerPolicy = "no-referrer";
    i.onload = () => { el.innerHTML = ""; el.appendChild(i); el.classList.add("ok"); };
    i.onerror = () => el.classList.add("none");
    i.src = r.src;
  });
}
function zoom(src) {
  let lb = document.getElementById("lb");
  if (!lb) {
    lb = document.createElement("div"); lb.id = "lb";
    lb.onclick = () => lb.classList.remove("on");
    document.body.appendChild(lb);
  }
  lb.innerHTML = '<img alt="Enlarged view" src="' + esc(src) + '">';
  lb.classList.add("on");
}

/* ---------- Geography, weather (Open-Meteo, free) ---------- */
const hav = (a, b) => {
  const r = x => x * Math.PI / 180, dl = r(b[0] - a[0]), dn = r(b[1] - a[1]);
  const h = Math.sin(dl / 2) ** 2 + Math.cos(r(a[0])) * Math.cos(r(b[0])) * Math.sin(dn / 2) ** 2;
  return 12742 * Math.asin(Math.sqrt(h));
};
async function geocode(name) {
  try {
    const res = await fetch("https://geocoding-api.open-meteo.com/v1/search?count=5&language=en&format=json&name=" + encodeURIComponent(name));
    const j = await res.json();
    const r = (j.results || []).find(x => x.country_code === "IN") || (j.results || [])[0];
    return r ? [r.latitude, r.longitude] : null;
  } catch (e) { return null; }
}
async function getWeather(lat, lon) {
  const u = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=5`;
  return (await fetch(u)).json();
}
const wxc = c => c === 0 ? ["☀️", "Clear sky"] : c < 3 ? ["⛅", "Partly cloudy"] : c === 3 ? ["☁️", "Overcast"] : c < 50 ? ["🌫️", "Fog"] : c < 70 ? ["🌧️", "Rain"] : c < 80 ? ["❄️", "Snow"] : c < 90 ? ["🌦️", "Showers"] : ["⛈️", "Thunderstorm"];

/* ---------- Map (Leaflet + OpenStreetMap, free) ---------- */
let _LL = null;
const loadLeaflet = () => _LL || (_LL = new Promise((ok, no) => {
  if (window.L) return ok();
  const l = document.createElement("link"); l.rel = "stylesheet"; l.href = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"; document.head.appendChild(l);
  const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"; s.onload = ok; s.onerror = () => { _LL = null; no(); }; document.head.appendChild(s);
}));
const GC = {};
async function wikiGeo(q) {
  if (q in GC) return GC[q];
  let r = null;
  try {
    const res = await fetch("https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrlimit=1&prop=coordinates&gsrsearch=" + encodeURIComponent(q));
    const j = await res.json();
    const pg = j.query && Object.values(j.query.pages)[0];
    r = pg && pg.coordinates && pg.coordinates[0] ? [pg.coordinates[0].lat, pg.coordinates[0].lon] : null;
  } catch (e) { }
  return (GC[q] = r);
}

/* ---------- Reviews & Budget maths ---------- */
const getRev = n => { try { return JSON.parse(localStorage.getItem("ym_rev_" + n) || "[]"); } catch (e) { return []; } };
const putRev = (n, a) => { try { localStorage.setItem("ym_rev_" + n, JSON.stringify(a)); } catch (e) { } };
const stars = r => "★".repeat(clamp(r, 0, 5)) + "☆".repeat(5 - clamp(r, 0, 5));
const nr = o => Object.fromEntries(TYPES.map(t => [t, N(o && o[t])]));
const normRates = r => ({ room: nr(r?.room), food: nr(r?.food), local: nr(r?.local), activities: N(r?.activities) });
function calc(r, n, ty, days, nights) {
  const stay = Math.ceil(n / 2) * r.room[ty] * nights;
  const food = n * r.food[ty] * days;
  const loc = r.local[ty] * Math.ceil(n / 4) * days;
  const act = n * r.activities * days;
  return { stay, food, loc, act, sub: stay + food + loc + act, rooms: Math.ceil(n / 2) };
}
