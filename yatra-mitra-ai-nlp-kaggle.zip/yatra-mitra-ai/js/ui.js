/* ===== ui.js - NLP-first -> Kaggle-fallback -> final response UI & events ===== */

const $ = s => document.querySelector(s);
const chat = $("#chat"), input = $("#q");
const DOTS = '<span class="dots"><span></span><span></span><span></span></span>';
const ctx = { place: null, history: [], nlp: "", plan: null };
let flow = null;

function add(cls, html, isText) {
  const r = document.createElement("div"); r.className = "row " + cls;
  if (cls === "bot") r.innerHTML = '<div class="av">YM</div>';
  const m = document.createElement("div"); m.className = "msg";
  isText ? (m.textContent = html) : (m.innerHTML = html);
  r.appendChild(m); chat.appendChild(r); chat.scrollTop = chat.scrollHeight;
  return m;
}
const fill = (m, h) => { m.innerHTML = h; hydrate(m); chat.scrollTop = chat.scrollHeight; };
const chips = a => `<div class="chips">` + a.map(([l, q]) => `<button class="chip" data-q="${esc(q)}">${esc(l)}</button>`).join("") + "</div>";
const takeNLP = () => { const t = ctx.nlp; ctx.nlp = ""; return t; };
async function bot(html) { const m = add("bot", DOTS); await sleep(250); fill(m, html + takeNLP()); return m; }
const ask = (h, o) => bot(h + chips(o.concat([["Cancel", "@cancel"]])));

async function work(fn) {
  const m = add("bot", DOTS);
  try { const r = await fn(m); fill(m, (typeof r === "string" ? r : r.html) + takeNLP()); if (r && r.after) await r.after(m); }
  catch (e) { fill(m, errHTML(e)); }
  return m;
}
function errHTML(e) {
  if (e.message === "NO_KEY") return `<b>API key missing.</b><div class="setup">Open <code>js/config.js</code>, paste your API key into <code>API_KEY</code>, choose the <code>PROVIDER</code> and save. Then refresh this page.</div>`;
  return `Sorry, the AI request failed: <b>${esc(e.message)}</b><div class="setup">Check your API key, model name and internet connection in <code>js/config.js</code>, then try again.</div>`;
}

const START = [
  ["3-day Vizag trip", "I have a 3 days trip to Vizag from Hyderabad for 2 people"],
  ["Best time for Goa", "Best time to visit Goa"],
  ["Telugu: vizag lo emi chudali?", "vizag lo emi chudali?"],
  ["Where to go in December", "Where to go in December"],
  ["Goa vs Manali", "Compare Goa vs Manali"],
  ["Hidden gems in Kerala", "Suggest less crowded places in Kerala"]
];
const POP = ["Goa", "Visakhapatnam", "Manali", "Jaipur", "Munnar", "Leh Ladakh"];
const CITIES = ["Hyderabad", "Chennai", "Bengaluru", "Mumbai", "Delhi", "Kolkata", "Pune"];
const placeChips = P => [
  ["📸 Photos", "@photos:" + P], ["⭐ Reviews", "@reviews:" + P], ["🗺️ Plan my trip", "Plan a 3 day trip to " + P],
  ["🌦️ Weather", "@weather:" + P], ["🎒 Packing", "@pack:" + P], ["📍 Map", "@map:" + P],
  ["💰 Trip cost", "@budget:" + P], ["⚖️ Compare", "@compare"]
];

function nlpPanel(u, sourceUsed = "NLP", dsCount = 0) {
  const det = [u.days && u.days + " days", u.travellers && u.travellers + " travellers", u.origin && "from " + u.origin, u.month, u.interest, u.hotel].filter(Boolean).map(esc).join(", ") || "none";
  const c = clamp(u.confidence, 0, 100);
  return `<details class="nlp"><summary>🧠 Pipeline: ${esc(sourceUsed)} (${c}% NLP conf · ${dsCount} CSV hits)</summary><div>1. <b>Language:</b> ${esc(u.language || "English")}<br>2. <b>Intent:</b> ${esc(u.intent)}<br>3. <b>Place:</b> ${esc(u.place || "none")}<br>4. <b>Details found:</b> ${det}<br>5. <b>Confidence:</b> <span class="conf"><i style="width:${c}%"></i></span> ${c}%<br>6. <b>Dataset:</b> ${esc(getDatasetStatus())}<br>7. <b>Model:</b> ${esc(CONFIG.PROVIDER)} / ${esc(modelName())}</div></details>`;
}

/* ---------- main router: 1) NLP first -> 2) Kaggle dataset fallback -> 3) final response ---------- */
async function respond(text) {
  ctx.nlp = "";
  if (flow) return flowStep(text);
  if (text[0] === "@") return act(text);

  const m = add("bot", DOTS);
  let u;
  try { u = await understand(text, ctx.history); } catch (e) { return fill(m, errHTML(e)); }

  const lowConf = N(u.confidence) < N(CONFIG.NLP_CONFIDENCE_THRESHOLD || 65);
  const needsPlaceFallback = !u.place && u.intent !== "greeting" && u.intent !== "month_ideas" && u.intent !== "interest_ideas" && u.intent !== "surprise";
  let dsMatches = [];
  let sourceUsed = "NLP";

  if (lowConf || needsPlaceFallback || u.intent === "chat") {
    dsMatches = await queryKaggleDataset(text, u.place || ctx.place);
    if (dsMatches.length && (lowConf || needsPlaceFallback || !u.reply)) {
      sourceUsed = "NLP + Kaggle Fallback";
      if (!u.place) {
        u.place = dsMatches[0].city || dsMatches[0].name || null;
      }
      try {
        u.reply = await answerWithDatasetFallback(text, u, dsMatches);
      } catch (e) { }
    } else if (dsMatches.length) {
      sourceUsed = "NLP + Kaggle Reference";
    }
  }

  ctx.history.push({ role: "user", content: text }, { role: "assistant", content: u._raw || "" });
  ctx.history = ctx.history.slice(-CONFIG.MAX_HISTORY);
  ctx.nlp = nlpPanel(u, sourceUsed, dsMatches.length);
  if (u.place) ctx.place = u.place;
  const P = u.place || ctx.place, rm = () => m.closest(".row")?.remove();

  switch (u.intent) {
    case "trip_plan": {
      rm(); if (!P) return askPlace("@plan");
      const d = { place: P, days: clamp(u.days || 3, 1, 7), n: clamp(u.travellers || 2, 1, 40), ty: TYPES.includes(u.hotel) ? u.hotel : "medium", origin: u.origin || null };
      if (d.origin) return doPlan(d);
      flow = { t: "origin", d };
      return ask(`A <b>${d.days}-day trip to ${esc(P)}</b> for ${d.n}. Which city are you starting from? I will compare train, flight and car costs.`, CITIES.filter(x => x !== P).map(x => [x, "@from:" + x]).concat([["Skip (no travel cost)", "@skip"]]));
    }
    case "budget": rm(); return startBudget(P);
    case "weather": rm(); return P ? doWeather(P) : askPlace("@weather");
    case "packing": rm(); return P ? doPack(P, u.month) : askPlace("@pack");
    case "map": rm(); return P ? doMap(P) : askPlace("@map");
    case "photos": rm(); return P ? doPhotos(P) : askPlace("@photos");
    case "reviews": rm(); return P ? doReviews(P) : askPlace("@reviews");
    case "compare": rm(); return u.places && u.places.length >= 2 ? doCompare(u.places[0], u.places[1]) : ask("Which two places should I compare? Try <b>Goa vs Manali</b>.", [["Goa vs Manali", "Compare Goa vs Manali"], ["Jaipur vs Udaipur", "Compare Jaipur vs Udaipur"]]);
    case "month_ideas": rm(); return doIdeas({ month: u.month || MONTHS[new Date().getMonth()] });
    case "interest_ideas": rm(); return doIdeas({ interest: u.interest || "beach" });
    case "surprise": rm(); return doIdeas({ surprise: true });
    default: {
      const extraDS = dsMatches.length ? formatDatasetMatches(dsMatches) : "";
      const chipBlock = (P && u.intent === "chat") ? chips(placeChips(P)) : "";
      fill(m, md(u.reply || "I can help with any place in India. What would you like to know?") + extraDS + chipBlock + takeNLP());
    }
  }
}

/* ---------- buttons / actions ---------- */
function askPlace(next) { flow = { t: "place", next }; return ask("Which place in India?", POP.map(x => [x, next + ":" + x])); }

async function act(t) {
  const i = t.indexOf(":"), k = i < 0 ? t : t.slice(0, i), a = i < 0 ? "" : t.slice(i + 1).trim();
  const need = fn => (a ? fn(a) : askPlace(k));
  switch (k) {
    case "@budget": return startBudget(a || null);
    case "@weather": return need(doWeather);
    case "@pack": return need(P => doPack(P));
    case "@map": return need(doMap);
    case "@photos": case "@gallery": return need(doPhotos);
    case "@reviews": return need(doReviews);
    case "@pdf": return printPlan();
    case "@surprise": return doIdeas({ surprise: true });
    case "@plan": return bot("<h3>🗺️ Plan my trip</h3>Tell me your idea in one line, in any language, for example:<ul><li>I have a 3 days trip to Vizag from Hyderabad for 4 people</li><li>5 day luxury trip to Goa from Bengaluru</li></ul>I will suggest the whole trip with budget by train, flight and car, top places, timings, costs and photos." + chips([["3 days Vizag", "I have a 3 days trip to Vizag from Hyderabad for 2 people"], ["4 days Goa", "Plan 4 days in Goa from Mumbai"], ["5 days Munnar", "Plan 5 days in Munnar from Bengaluru"]]));
    case "@interest": return bot("What kind of trip are you looking for?" + chips([["🏖️ Beaches", "Best beach destinations in India"], ["⛰️ Hill stations", "Best hill stations in India"], ["🏰 Heritage", "Best heritage destinations in India"], ["🛕 Spiritual", "Best spiritual destinations in India"], ["🐅 Wildlife", "Best wildlife destinations in India"], ["🧗 Adventure", "Best adventure destinations in India"]]));
    case "@month": return bot("Which month are you travelling in?" + chips([["This month", "Where to go this month"]].concat(MONTHS.map(m => [m.slice(0, 3), "Where to go in " + m]))));
    case "@compare": return bot("Pick a pair, or type your own like <b>Goa vs Manali</b>." + chips([["Goa vs Manali", "Compare Goa vs Manali"], ["Jaipur vs Udaipur", "Compare Jaipur vs Udaipur"], ["Munnar vs Ooty", "Compare Munnar vs Ooty"], ["Shimla vs Darjeeling", "Compare Shimla vs Darjeeling"]]));
    case "@cancel": return bot("Okay! Ask me anything about India travel.");
  }
}

/* ---------- guided flows ---------- */
function startBudget(P) {
  flow = { t: "budget", d: {} };
  if (P) { flow.d.place = P; ctx.place = P; return askPersons(); }
  return ask("<h3>💰 Budget calculator</h3>Which destination? Pick one or type any place in India.", (ctx.place ? [ctx.place] : []).concat(POP.slice(0, 4)).map(x => [x, "@dest:" + x]));
}
const num = a => a.map(x => [String(x), String(x)]);
const askPersons = () => ask(`Great, <b>${esc(flow.d.place)}</b>. How many people are travelling?`, num([1, 2, 3, 4, 5, 6, 8]));
const askHotel = () => ask("Which type of hotel do you prefer?<ul><li><b>Basic</b>: simple, clean stay</li><li><b>Medium</b>: 3-star comfort</li><li><b>Luxury</b>: 4-5 star or resort</li></ul>", [["Basic", "basic"], ["Medium", "medium"], ["Luxury", "luxury"]]);
const askNights = () => ask("How many days (nights) will you stay at the hotel?", num([1, 2, 3, 4, 5, 7, 10]));

async function flowStep(raw) {
  const low = raw.toLowerCase().trim(), f = flow;
  if (/^(@cancel|cancel|stop|exit|quit)$/.test(low)) { flow = null; return bot("Okay, cancelled. What would you like to explore next?" + chips(START)); }
  if (f.t === "origin") { flow = null; return doPlan({ ...f.d, origin: /^@skip|^skip/.test(low) ? null : raw.replace(/^@from:/, "").trim() }); }
  if (f.t === "place") { flow = null; return raw[0] === "@" ? act(raw) : act(f.next + ":" + raw.trim()); }
  if (raw[0] === "@" && !raw.startsWith("@dest:")) { flow = null; return act(raw); }

  const d = f.d, v = parseInt((low.match(/\d+/) || [])[0], 10);
  if (!d.place) { d.place = cap(raw.replace(/^@dest:/, "").trim()); ctx.place = d.place; return askPersons(); }
  if (!d.n) { if (!(v >= 1 && v <= 40)) return ask("Please enter the number of travellers (1 to 40).", num([1, 2, 3, 4, 6])); d.n = v; return askHotel(); }
  if (!d.ty) {
    const ty = /lux|premium|resort|5|five/.test(low) ? "luxury" : /med|mid|3|three/.test(low) ? "medium" : /bas|budget|cheap|low/.test(low) ? "basic" : null;
    if (!ty) return ask("Please choose Basic, Medium or Luxury.", [["Basic", "basic"], ["Medium", "medium"], ["Luxury", "luxury"]]);
    d.ty = ty; return askNights();
  }
  if (!(v >= 1 && v <= 30)) return ask("Please enter the number of nights (1 to 30).", num([1, 2, 3, 4, 5, 7]));
  flow = null;
  return work(async () => budgetHTML(d.place, normRates((await genRates(d.place)).rates), d.n, d.ty, v));
}

/* ---------- feature renderers ---------- */
function budgetHTML(place, r, n, ty, nights) {
  const c = calc(r, n, ty, nights, nights), tot = Math.round(c.sub * 1.05), misc = tot - c.sub;
  const rows = [[`Hotel (${c.rooms} room${c.rooms > 1 ? "s" : ""})`, c.stay, "#0f7b8a"], ["Food", c.food, "#ff9f1c"], ["Local transport", c.loc, "#e4572e"], ["Sightseeing and activities", c.act, "#6a4c93"], ["Miscellaneous (5%)", misc, "#8aa0a6"]];
  const alt = TYPES.map(k => `<div class="${k === ty ? "on" : ""}">${HOTEL[k]}<b>${inr(calc(r, n, k, nights, nights).sub * 1.05)}</b></div>`).join("");
  return `<div class="bud"><h3>Trip budget: ${esc(place)}</h3><div class="sub">${n} traveller${n > 1 ? "s" : ""} · ${HOTEL[ty]} hotel · ${nights} night${nights > 1 ? "s" : ""}</div>
  <div class="total">${inr(tot)}</div><div class="sub">About ${inr(n ? tot / n : tot)} per person · ${inr(nights ? tot / nights : tot)} per day</div>
  <div class="bar">${rows.map(x => `<i style="width:${tot > 0 ? (x[1] / tot * 100).toFixed(1) : 0}%;background:${x[2]}"></i>`).join("")}</div>
  ${rows.map(x => `<div class="line"><i style="background:${x[2]}"></i>${esc(x[0])}<b>${inr(x[1])}</b></div>`).join("")}
  <div class="sub" style="margin-top:10px">Same trip with other hotel types:</div><div class="alt">${alt}</div>
  <small>AI-estimated rates. Rooms assume 2 people each. Flights, trains and shopping are not included.</small></div>` +
  chips([["Try another hotel type", "@budget:" + place], ["Another destination", "@budget"], ["🗺️ Plan my trip", "Plan a 3 day trip to " + place]]);
}

const doPlan = d => work(async () => {
  const p = await genPlan(d.place, d.days, d.n, d.origin);
  ctx.place = p.place || d.place; ctx.plan = p;
  return planHTML(p, d);
});

function planHTML(p, d) {
  const { n, days, ty, origin } = d, r = normRates(p.rates), c = calc(r, n, ty, days, Math.max(days - 1, 0)), base = c.stay + c.food + c.act;
  let tbl = "", note = "";
  if (origin) {
    const M = (p.transport || []).map(m => {
      const car = /car/i.test(m.mode), tc = car ? Math.ceil(n / 4) * N(m.cost_return_per_vehicle) : n * N(m.cost_return_per_person);
      return { ...m, tc, tot: Math.round((base + (car ? 300 * days : c.loc) + tc) * 1.05) };
    }), ok = M.filter(m => m.practical !== false);
    const ch = ok.length ? ok.reduce((a, b) => (b.tot < a.tot ? b : a), ok[0]) : null;
    const fa = ok.length ? ok.reduce((a, b) => (N(b.one_way_hours) < N(a.one_way_hours) ? b : a), ok[0]) : null;
    const ic = { train: "🚆", flight: "✈️", car: "🚗" };
    tbl = `<b>Budget by travel mode</b> (from ${esc(origin)}, return trip, ${n} traveller${n > 1 ? "s" : ""}):<div class="scroll"><table class="cmp"><tr><td>Travel by</td><td>One way</td><td>Transport</td><td>Total trip</td></tr>` +
      M.map(m => {
        const i = ic[String(m.mode).toLowerCase()] || "🚌";
        return m.practical === false
          ? `<tr><th>${i} ${esc(m.mode)}</th><td colspan="3"><small>${esc(m.note || "Not practical for this route.")}</small></td></tr>`
          : `<tr><th>${i} ${esc(m.mode)}${m === ch ? ' <span class="tag">Cheapest</span>' : ""}${m === fa ? ' <span class="tag t2">Fastest</span>' : ""}</th><td>${N(m.one_way_hours)} hrs</td><td>${inr(m.tc)}</td><td><b>${inr(m.tot)}</b><br><small>${inr(n ? m.tot / n : m.tot)} per person</small></td></tr>`;
      }).join("") + `</table></div>`;
  } else note = `<small>Travel cost to ${esc(p.place)} is not included. Tell me your starting city next time to compare train, flight and car.</small><br>`;

  const dayHTML = (p.itinerary || []).map(dy => `<div class="daytitle">Day ${esc(dy.day)}: ${esc(dy.title)}</div>` + (dy.spots || []).map(s =>
    `<div class="spot">${ph(s.name + " " + p.place, s.name + " India", p.place + " India")}<div class="si"><b>${esc(s.name)}</b><span>🕒 ${esc(s.timing)}</span><span>🎟️ ${esc(s.cost)}</span><span>✨ ${esc(s.special)}</span></div></div>`).join("")).join("");

  return `<div class="plan"><h3>🗺️ ${days}-day ${esc(p.place)} trip</h3><div>${esc(p.summary)}</div>
  <div class="meta"><span>👥 ${n} traveller${n > 1 ? "s" : ""}</span><span>🏨 ${HOTEL[ty]} hotel</span><span>📅 Best: ${esc(p.best_time)}</span>${origin ? `<span>📍 From ${esc(origin)}</span>` : ""}</div>${tbl}${note}
  <b>On-site cost</b> (stay ${inr(c.stay)}, food ${inr(c.food)}, activities ${inr(c.act)}, local travel ${inr(c.loc)}): about <b>${inr(base + c.loc)}</b>${dayHTML}
  <br><b>Must-try food:</b> ${esc((p.food || []).join(", "))}<br><b>Tips:</b>${"<ul>" + (p.tips || []).map(t => `<li>${esc(t)}</li>`).join("") + "</ul>"}
  <small>AI-generated estimates. Timings and prices change often; confirm locally before you go.</small></div>` +
  chips([["📸 Photos", "@photos:" + p.place], ["⭐ Reviews", "@reviews:" + p.place], ["⬇️ Download PDF", "@pdf"], ["📍 Map", "@map:" + p.place], ["🎒 Packing list", "@pack:" + p.place], ["🌦️ Weather", "@weather:" + p.place], ["Change hotel or people", "@budget:" + p.place]]);
}

const doIdeas = a => work(async () => {
  const j = await genIdeas(a), ps = j.places || [];
  let h = `<h3>${esc(j.title)}</h3><div class="grid">` + ps.map(p => `<button class="card" data-q="Tell me about ${esc(p.name)}"><b>${esc(p.name)}</b><span>${esc(p.state)}</span><em>${esc(p.best_time || "")}</em><span>${esc(p.why)}</span></button>`).join("") + "</div>";
  if (a.surprise && ps[0]) { ctx.place = ps[0].name; h += chips(placeChips(ps[0].name)); }
  return h;
});

const doCompare = (a, b) => work(async () => {
  const j = await genCompare(a, b), A = j.a || {}, B = j.b || {};
  const row = (l, f) => `<tr><th>${l}</th><td>${f(A)}</td><td>${f(B)}</td></tr>`;
  return `<h3>${esc(A.name || a)} vs ${esc(B.name || b)}</h3><div class="scroll"><table class="cmp"><tr><th></th><td><b>${esc(A.name || a)}</b></td><td><b>${esc(B.name || b)}</b></td></tr>` +
    row("State", p => esc(p.state)) + row("Best time", p => esc(p.best_time)) + row("Ideal stay", p => N(p.ideal_days) + " days") + row("Cost per day", p => inr(p.cost_per_person_per_day_inr) + " per person") +
    row("Top sights", p => esc((p.top_sights || []).slice(0, 3).join(", "))) + row("Must-try food", p => esc((p.food || []).slice(0, 2).join(", "))) + row("Vibe", p => esc(p.vibe)) +
    `</table></div><p><b>Verdict:</b> ${esc(j.verdict)}</p>` + chips([["Budget for " + (A.name || a), "@budget:" + (A.name || a)], ["Budget for " + (B.name || b), "@budget:" + (B.name || b)]]);
});

const doPhotos = P => work(async () => {
  const j = await genSpots(P), pl = j.place || P; ctx.place = pl;
  return `<h3>📸 Photos: ${esc(pl)}</h3>Popular spots. Tap a photo to enlarge.<div class="gal">` +
    (j.spots || []).slice(0, 8).map(s => `<figure>${ph(s.name + " " + pl, s.name + " India", pl + " India")}<figcaption>${esc(s.name)}</figcaption></figure>`).join("") +
    `</div><small>Photos load from Wikipedia and Wikimedia Commons. More on <a target="_blank" rel="noopener" href="https://www.google.com/search?tbm=isch&q=${encodeURIComponent(pl + " tourism")}">Google Images</a>.</small>` +
    chips([["⭐ Reviews", "@reviews:" + pl], ["🗺️ Plan my trip", "Plan a 3 day trip to " + pl], ["📍 Map", "@map:" + pl]]);
});

function revBody(P) {
  const a = getRev(P); if (!a.length) return "<small>No reviews from you yet. Be the first!</small>";
  const avg = a.reduce((s, r) => s + r.s, 0) / a.length;
  return `<div><span class="stars">${stars(Math.round(avg))}</span> <b>${avg.toFixed(1)} / 5</b> · ${a.length} saved review${a.length > 1 ? "s" : ""}</div>` + a.map(r => `<div class="rev"><span class="stars">${stars(r.s)}</span> <b>${esc(r.u)}</b><br>${esc(r.t)}</div>`).join("");
}
const doReviews = P => work(async () => {
  const j = await genReviews(P), li = a => "<ul>" + (a || []).map(x => `<li>${esc(x)}</li>`).join("") + "</ul>";
  return `<h3>⭐ Reviews: ${esc(P)}</h3><div><span class="stars">${stars(Math.round(N(j.rating)))}</span> <b>${N(j.rating).toFixed(1)} / 5</b> <small>(AI summary of general traveller sentiment, not live ratings)</small></div><p>${esc(j.summary)}</p>
  <b>👍 Travellers like</b>${li(j.likes)}<b>👎 Watch out for</b>${li(j.dislikes)}<b>💡 Tips</b>${li(j.tips)}
  <div class="rv" data-p="${esc(P)}"><b>Your reviews</b><div class="revbody">${revBody(P)}</div><div class="rform"><b>Write your review</b><div>${[1, 2, 3, 4, 5].map(i => `<button type="button" class="star" data-s="${i}" aria-label="${i} stars">★</button>`).join("")}</div><input placeholder="Your name (optional)" maxlength="30"><textarea rows="2" placeholder="Share your experience..." maxlength="300"></textarea><button type="button" class="chip" data-post="1">Post review</button><span class="rmsg"></span></div></div>
  <div class="links"><a target="_blank" rel="noopener" href="https://www.google.com/maps/search/${encodeURIComponent(P + " tourist places")}">Google Maps reviews</a><a target="_blank" rel="noopener" href="https://www.tripadvisor.in/Search?q=${encodeURIComponent(P)}">TripAdvisor</a><a target="_blank" rel="noopener" href="https://www.youtube.com/results?search_query=${encodeURIComponent(P + " travel vlog")}">Travel vlogs</a></div>` +
  chips([["📸 Photos", "@photos:" + P], ["🗺️ Plan my trip", "Plan a 3 day trip to " + P]]);
});
function postReview(box) {
  const n = box.dataset.p, s = +box.dataset.s, t = box.querySelector("textarea").value.trim(), m = box.querySelector(".rmsg");
  if (!s || !t) { m.textContent = "Please pick a star rating and write a short review."; return; }
  const a = getRev(n); a.unshift({ u: box.querySelector("input").value.trim() || "You", s, t }); putRev(n, a);
  box.querySelector(".revbody").innerHTML = revBody(n); box.querySelector("textarea").value = ""; m.textContent = "Thanks! Your review was saved.";
}

const doWeather = P => work(async () => {
  let g = await geocode(P);
  if (!g) { const s = await genSpots(P); g = [N(s.lat), N(s.lon)]; }
  const j = await getWeather(g[0], g[1]), c = j.current, d = j.daily, [e, t] = wxc(c.weather_code);
  return `<h3>🌦️ Weather: ${esc(P)}</h3><div class="wxnow"><span class="big">${e}</span><div><b>${Math.round(c.temperature_2m)}°C</b> ${t}<br><small>Humidity ${c.relative_humidity_2m}% · Wind ${Math.round(c.wind_speed_10m)} km/h</small></div></div><div class="wx">` +
    d.time.map((x, i) => `<div><small>${new Date(x).toLocaleDateString("en-IN", { weekday: "short", day: "numeric" })}</small><span>${wxc(d.weather_code[i])[0]}</span><b>${Math.round(d.temperature_2m_max[i])}°</b><small>${Math.round(d.temperature_2m_min[i])}° · ${d.precipitation_probability_max[i]}% rain</small></div>`).join("") +
    `</div><small>Live data from Open-Meteo.</small>` + chips([["🎒 Packing list", "@pack:" + P], ["📍 Map", "@map:" + P], ["🗺️ Plan my trip", "Plan a 3 day trip to " + P]]);
});

const doPack = (P, month) => work(async () => {
  const mo = month || MONTHS[new Date().getMonth()], j = await genPack(P, mo), g = j.groups || [], tot = g.reduce((a, x) => a + (x.items || []).length, 0);
  return `<h3>🎒 Packing list: ${esc(P)}</h3><div class="pk"><small>Tailored for ${esc(mo)}. Tick items as you pack.</small><div class="pkbar"><i></i></div><small class="pkn">0 of ${tot} packed</small>` +
    g.map(x => `<div class="grp">${esc(x.title)}</div>` + (x.items || []).map(i => `<label><input type="checkbox"><span>${esc(i)}</span></label>`).join("")).join("") + `</div>` +
    chips([["🌦️ Live weather", "@weather:" + P], ["🗺️ Plan my trip", "Plan a 3 day trip to " + P]]);
});

const doMap = P => work(async () => {
  await loadLeaflet().catch(() => { throw new Error("The map needs internet (OpenStreetMap)"); });
  return {
    html: `<h3>📍 Map: ${esc(P)}</h3><div class="map"></div><small class="mapnote">Placing pins for the top spots...</small>` + chips([["📸 Photos", "@photos:" + P], ["🗺️ Plan my trip", "Plan a 3 day trip to " + P], ["🌦️ Weather", "@weather:" + P]]),
    after: async m => {
      const s = await genSpots(P), c = (await geocode(P)) || [N(s.lat), N(s.lon)];
      const map = L.map(m.querySelector(".map")).setView(c, 12);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "© OpenStreetMap contributors" }).addTo(map);
      L.marker(c).addTo(map).bindPopup("<b>" + esc(P) + "</b>").openPopup();
      const pts = [c], sp = (s.spots || []).slice(0, 8);
      const geo = await Promise.all(sp.map(x => wikiGeo(x.name + " " + P)));
      sp.forEach((x, i) => {
        const g = geo[i] || [N(x.lat), N(x.lon)];
        if (Number.isFinite(g[0]) && Number.isFinite(g[1]) && (g[0] !== 0 || g[1] !== 0) && hav(g, c) < 150) {
          pts.push(g);
          L.marker(g).addTo(map).bindPopup(esc(x.name));
        }
      });
      if (pts.length > 1) map.fitBounds(pts, { padding: [30, 30] });
      setTimeout(() => map.invalidateSize(), 250);
      m.querySelector(".mapnote").textContent = pts.length > 1 ? `Showing ${pts.length - 1} top spots. Tap a pin for its name.` : "Showing the city centre; spot pins were not found.";
    }
  };
});

async function printPlan() {
  const pl = [...document.querySelectorAll(".plan")].pop();
  if (!pl) return bot("Create a trip plan first (for example <b>3 days in Goa from Mumbai</b>), then I can export it as a PDF.");
  const w = window.open("", "_blank");
  if (!w) return bot("Please allow pop-ups so I can open the printable plan, then choose <b>Save as PDF</b>.");
  w.document.write(`<html><head><title>Yatra Mitra trip plan</title><style>body{font-family:Arial,sans-serif;max-width:800px;margin:20px auto;color:#222;font-size:13px;line-height:1.5}h3{color:#0f7b8a;font-size:24px;margin:0 0 6px}table{border-collapse:collapse;width:100%;margin:6px 0}td,th{border:1px solid #ccc;padding:6px;text-align:left}.daytitle{background:#0f7b8a;color:#fff;padding:6px 10px;margin:14px 0 6px;font-weight:bold}.spot{display:flex;gap:10px;margin-bottom:8px;break-inside:avoid;border:1px solid #ddd;padding:6px}.ph{width:120px;height:90px;flex:none;background:#eee}.ph img{width:100%;height:100%;object-fit:cover}.si span{display:block}.meta span{margin-right:12px}.tag{background:#ff9f1c;padding:1px 6px;border-radius:9px;font-size:11px}</style></head><body>${pl.innerHTML}<p style="color:#888">Generated by Yatra Mitra AI. Prices and timings are estimates; confirm locally.</p><script>window.onload=()=>setTimeout(()=>print(),500)<\/script></body></html>`);
  w.document.close();
  return bot("Your plan opened in a new tab. In the print window choose <b>Save as PDF</b> as the destination.");
}

/* ---------- events ---------- */
function send(t, label) { t = t.trim(); if (!t) return; add("user", label || t, true); input.value = ""; respond(t); }
$("#f").addEventListener("submit", e => { e.preventDefault(); send(input.value); });
document.addEventListener("click", e => {
  const st = e.target.closest(".star");
  if (st) { const b = st.closest(".rv"); b.dataset.s = st.dataset.s; b.querySelectorAll(".star").forEach(x => x.classList.toggle("on", +x.dataset.s <= +st.dataset.s)); return; }
  const pb = e.target.closest("[data-post]"); if (pb) return postReview(pb.closest(".rv"));
  const im = e.target.closest(".ph img"); if (im) return zoom(im.src);
  const c = e.target.closest("[data-q]");
  if (c) send(c.dataset.q, c.classList.contains("feat") || c.classList.contains("card") ? c.querySelector("b")?.textContent : c.textContent);
});
document.addEventListener("change", e => {
  const b = e.target.closest(".pk"); if (!b || e.target.type !== "checkbox") return;
  const a = b.querySelectorAll("input"), on = b.querySelectorAll("input:checked");
  b.querySelector(".pkbar i").style.width = (a.length ? (on.length / a.length * 100) : 0) + "%";
  b.querySelector(".pkn").textContent = on.length + " of " + a.length + " packed";
});

function welcome() {
  const missing = !CONFIG.API_KEY || CONFIG.API_KEY.startsWith("PASTE");
  add("bot", `<div class="hero"><h2>Namaste! 🙏</h2><p class="tag-line">Your AI travel guide for every corner of India</p><div class="stats"><div><b>NLP + CSV</b>hybrid brain</div><div><b>Any</b>place in India</div><div><b>11</b>smart tools</div></div></div>Ask me anything about any city, town or hidden gem in India — I check NLP first, fall back to the Kaggle dataset when needed, and give you a full travel answer.` +
    (missing ? `<div class="setup"><b>One-time setup:</b> open <code>js/config.js</code>, paste your API key and refresh.</div>` : "") + chips(START));
  loadKaggleDataset();
}
$("#quick").innerHTML = [["🗺️ Plan trip", "@plan"], ["💰 Budget", "@budget"], ["📸 Photos", "@gallery"], ["🌦️ Weather", "@weather"], ["🎒 Packing", "@pack"], ["📍 Map", "@map"], ["🎲 Surprise me", "@surprise"]].map(([l, q]) => `<button class="chip" data-q="${q}">${l}</button>`).join("");
$("#theme").onclick = e => { const d = document.documentElement, dk = d.dataset.theme === "dark"; d.dataset.theme = dk ? "" : "dark"; e.target.textContent = dk ? "🌙 Dark mode" : "☀️ Light mode"; };
$("#clear").onclick = () => { chat.innerHTML = ""; flow = null; ctx.history = []; ctx.place = null; welcome(); };
const SR = window.SpeechRecognition || window.webkitSpeechRecognition, mic = $("#mic");
if (SR) {
  const r = new SR();
  r.lang = "en-IN";
  r.onresult = e => send(e.results[0][0].transcript);
  r.onerror = () => mic.classList.remove("on");
  r.onend = () => mic.classList.remove("on");
  mic.onclick = () => { mic.classList.add("on"); try { r.start(); } catch (e) { mic.classList.remove("on"); } };
} else mic.hidden = true;

welcome(); input.focus();
